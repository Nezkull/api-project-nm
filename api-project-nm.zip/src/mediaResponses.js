const fs = require('fs');
const path = require('path');

const loadFile = (request, response, fileLoc, mimeType) => {
  const file = path.resolve(__dirname, fileLoc);

  fs.stat(file, (err, stats) => {
    if (err) {
      if (err.code === 'ENOENT') {
        response.writeHead(404);
      }
      return response.end(err);
    }

    let { range } = request.headers;

    if (!range) {
      range = 'bytes=0-';
    }

    const positions = range.replace(/bytes=/, '').split('-');

    let start = parseInt(positions[0], 10);

    const total = stats.size;
    const end = positions[1] ? parseInt(positions[1], 10) : total - 1;

    if (start > end) {
      start = end - 1;
    }

    const chunksize = (end - start) + 1;

    response.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${total}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': mimeType,
    });

    const stream = fs.createReadStream(file, { start, end });

    stream.on('open', () => {
      stream.pipe(response);
    });

    stream.on('error', (streamErr) => {
      response.end(streamErr);
    });

    return stream;
  });
};

// Stephens idea, i swear
const getThisBread = (request, response) => {
  loadFile(request, response, '../media/bread.png', 'image/png');
};

const getLamp = (request, response) => {
  loadFile(request, response, '../media/lamp.png', 'image/png');
};

module.exports = {
  getThisBread,
  getLamp,
};
